package cz.johnyri.temp;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.io.*;

// Description of the UDF
@Description(
    name="CelsiusToFahrenheit",
    value="Returns a temperature in Fahrenheit from the temperature in Celsius.",
    extended="select CelsiusToFahrenheit(temperature) from hivesampletable limit 10;"
)
public class CelsiusToFahrenheit extends UDF {
	   // Accept a double input
    public double evaluate(double input) {
        // If the value is 0.0f, return a 0.0f
        // convert the input temperature and return it
        double temperature = 32 + ((9 * input) / 5);
        return temperature;
    }
}
