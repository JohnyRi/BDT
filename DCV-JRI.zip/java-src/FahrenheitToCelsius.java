package cz.johnyri.temp;
import org.apache.hadoop.hive.ql.exec.Description;
import org.apache.hadoop.hive.ql.exec.UDF;
import org.apache.hadoop.io.*;

// Description of the UDF
@Description(
    name="FahrenheitToCelsius",
    value="Returns a temperature in Celsius from the temperature in Fahrenheit.",
    extended="select FahrenheitToCelsius(temperature) from hivesampletable limit 10;"
)
public class FahrenheitToCelsius extends UDF {
	   // Accept a double input
    public double evaluate(double input) {
        // convert the input temperature and return it
        double temperature = ((input - 32) * 5) / 9;
        return temperature;
    }
}
